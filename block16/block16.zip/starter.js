// defining objects timmy, sarah, and rocky
// key values are - name of prescription, price per refill, refills left, subscriptions, and coupons

const timmy = {
  prescription: "acetaminophen",
  pricePerRefill: 25,
  refills: 3,
  subscription: false,
  coupon: true,
};

const sarah = {
  prescription: "diphenhydramine",
  pricePerRefill: 50,
  refills: 1,
  subscription: true,
  coupon: false,
};

const rocky = {
  prescription: "phenylephrine",
  pricePerRefill: 30,
  refills: 5,
  subscription: true,
  coupon: true,
};

function Cost(patientName, patient) {
  let Cost = patient.pricePerRefill * patient.refills;

  if (patient.subscription) {
    Cost *= 0.9; // 10% discount with a subscription
  }

  if (patient.coupon) {
    Cost *= 0.8; // 20% discount with a coupon
  }

  let message = patientName + ", Your grand total is $" + Cost + ".";
  return message;
}

console.log(Cost("Timmy", timmy));
console.log(Cost("Sarah", sarah));
console.log(Cost("Rocky", rocky));
